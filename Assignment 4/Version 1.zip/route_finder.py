from sys import argv
import copy
def main():
    mycosts=0       #The cost of the cell the person walked.
    current_position=[0,0]     #The current position of the person who tries to reach the opposite side.
    map_data=[]      #I will keep the map in a list.
    cost_list=[]     #My first row is about costs.I need a list to keeep them :)
    with open(argv[1].strip(),"r") as input:
        input_lines=input.readlines()
    
    for line in input_lines:
        for cost in line.strip().split():
            cost_list.append(cost)
        break
    cost1,cost2,cost3=int(cost_list[0]),int(cost_list[1]),int(cost_list[2])

    for line in input_lines[1:]:
        map_data.append(line.strip().split())
    
    while [] in map_data:
        map_data.remove([])
    
    count=1
    for mylist in map_data:
        if int(mylist[0])==1:
            current_position[0]=count
            current_position[1]=1
            break
        else:    
            count+=1

    cost_data_map = copy.deepcopy(map_data)      #I need a copy list to determine the costs.In recursion part,I am replacing some values with "X".It is getting problem unless I create a copy list.
    
    def get_current_value(cost_data_map, current_position):
        if type(current_position)==list:
            return int(cost_data_map[current_position[0] - 1][current_position[1] - 1])
    
    def right_trial():       #in recursion part,I am using this function in if statement. 
        mycopy=current_position.copy()
        if mycopy[1]!=len(map_data[0]):
            mycopy[1]+=1
            return mycopy
        
    def right():
        if current_position[1]!=len(map_data[0]):
            current_position[1]+=1
            return current_position
    
    def up_trial():
        mycopy=current_position.copy()
        if mycopy[0]!=1:
            mycopy[0]-=1
            return mycopy 
        
    def up():
        if current_position[0]!=1:
            current_position[0]-=1
            return current_position
    
    def down_trial():
        mycopy=current_position.copy()
        if mycopy[0]!=len(map_data):
            mycopy[0]+=1
            return mycopy
        
    def down():
        if current_position[0]!=len(map_data):
            current_position[0]+=1
            return current_position
    
    def left_trial():
        mycopy=current_position.copy()
        if mycopy[1]!=1:
            mycopy[1]-=1
            return mycopy

    def left():
        if current_position[1]!=1:
            current_position[1]-=1
            return current_position
    
    def cost(current_position):      #Each cost of the cell
        right_one_coordinate=[current_position[0],current_position[1]+1]
        upper_one_coordinate=[current_position[0]-1,current_position[1]]
        left_one_coordinate=[current_position[0],current_position[1]-1]
        down_one_coordinate=[current_position[0]+1,current_position[1]]
        right_up_coordinate=[current_position[0]-1,current_position[1]+1]
        left_up_coordinate=[current_position[0]-1,current_position[1]-1]
        left_down_coordinate=[current_position[0]+1,current_position[1]-1]
        right_down_coordinate=[current_position[0]+1,current_position[1]+1]

        cost3_check=[right_one_coordinate,upper_one_coordinate,left_one_coordinate,down_one_coordinate]
        cost2_check=[right_up_coordinate,left_up_coordinate,left_down_coordinate,right_down_coordinate]
    
        check_list=[right_one_coordinate,upper_one_coordinate,left_one_coordinate,down_one_coordinate,right_up_coordinate,left_up_coordinate,left_down_coordinate,right_down_coordinate]
        
        for location in check_list:
            if not 0 in location and location[1]!=len(cost_data_map[0])+1:
                if get_current_value(cost_data_map,location)==0:
                    if location in cost3_check:
                        return cost3
                    if location in cost2_check:
                        return cost2
                else:
                    if location==check_list[-1]:
                        return cost1
    
    def route_finder():
        nonlocal mycosts
        if get_current_value(cost_data_map,right_trial())==1:
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            right()
        elif get_current_value(cost_data_map,up_trial())==1:
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            up()
        elif get_current_value(cost_data_map,down_trial())==1:
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            down()
        elif get_current_value(cost_data_map,left_trial())==1:
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            left()
        
        if current_position[1]==len(map_data[0]):
            backup_cost=mycosts
            copy_map_data=copy.deepcopy(map_data)
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            left()
            small_cost()
        else:
            route_finder()

    def small_cost():
        nonlocal mycosts
        if get_current_value(cost_data_map,right_trial())==1 and backup_cost+cost(right_trial())<mycosts:
            mycosts=backup_cost
            map_data=copy_map_data
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            right()
        elif get_current_value(cost_data_map,up_trial())==1 and backup_cost+cost(up_trial())<mycosts:
            mycosts=backup_cost
            map_data=copy_map_data            
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            up()
        elif get_current_value(cost_data_map,down_trial())==1 and backup_cost+cost(down_trial())<mycosts:
            mycosts=backup_cost
            map_data=copy_map_data
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            down()
        elif get_current_value(cost_data_map,left_trial())==1 and backup_cost+cost(left_trial())<mycosts:
            mycosts=backup_cost
            map_data=copy_map_data            
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            left()
        
        if current_position[1]==len(map_data[0]):
            backup_cost=mycosts
            copy_map_data=copy.deepcopy(map_data)
            mycosts+=cost(current_position)
            map_data[current_position[0]-1][current_position[1]-1]="X"
            left()
            small_cost()
        else:
            route_finder()
 
    route_finder()
    
    
    
    
    
    
    
    
    
    
    
    def myfunc():
        route_finder()
        print(f"Cost of the route: {mycosts}")
        for mylist in map_data:
            for i in mylist:
                print(f"{i} ",end="")
            print()
    

    # myfunc()
    # myfunc()
    # myfunc()
    # myfunc()


    
    
    
    

    
    return current_position,right,up,down,left,cost
main()

