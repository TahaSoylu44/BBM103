from sys import argv
import locale
locale.setlocale(locale.LC_ALL, "en_US")
def main():
    datas=[]
    data_list=[]
    columns_dict={}
    with open(argv[1].strip(),"r",encoding="utf-8") as file:
        lines=file.readlines()
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="CREATE_TABLE":
                data_list.append(splitted_line[1])
                columns=splitted_line[2].split(",")  
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="INSERT":
                counter=0
                for index,character in enumerate(line):
                    if character==" ":
                        counter+=1
                        if counter==2:
                            datas.append(line[(index+1):].strip().split(","))
        for i in datas:
            counter=0
            for k in i:
                columns_dict.update({columns[counter]:k})
                counter+=1
                copied_dict=columns_dict.copy()
            data_list.append(copied_dict)
    return data_list
main()

def minus(a,b):
    return((max(len(str(a)),len(str(b)))+2)*"-")

def INSERT():
    mylist=[]
    for dictionary in main()[1:]:
        last_item=tuple(dictionary.keys())[-1]
    def TABLE():
        nonlocal mylist
        nonlocal dictionary
        nonlocal last_item
        a=dictionary.copy()
        mylist.append(a)
        for anydict in mylist:
            for key,value in anydict.items():
                WidthLists=[]
                if key!=last_item:
                    for i in mylist:
                        WidthLists.append(i[key])
                    width=max(len(str(key)),len(max(WidthLists,key=len)))
                    print(f"| {value:{width}} ",end="")
                else:
                    for i in mylist:
                        WidthLists.append(i[key])
                    width=max(len(str(key)),len(max(WidthLists,key=len)))
                    print(f"| {value:{width}} ",end="")
                    print("|")

    for dictionary in main()[1:]:
        last_item=tuple(dictionary.keys())[-1]
        print(22*"#"+" "+"INSERT"+" "+25*"#")
        print(f"Inserted into '{main()[0]}': {tuple(dictionary.values())}") 
        print()
        print(f"Table: {main()[0]}")  
    
        for key,value in dictionary.items():    
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
    
        for key,value in dictionary.items():
            if key!=last_item:
                print(f"| {key:<{len(minus(key,value))-2}} ",end="")
            else:
                print(f"| {key:<{len(minus(key,value))-2}} ",end="")
                print("|")

        for key,value in dictionary.items():
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
    
        TABLE()
        
        for key,value in dictionary.items():
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
        
        print(55*"#")
        print()

def CREATE():
    print(22*"#"+" "+"CREATE"+" "+25*"#")
    print(f"Table '{main()[0]}' created with columns: {list(main()[1].keys())}")
    print(55*"#")
    print()












        
















































