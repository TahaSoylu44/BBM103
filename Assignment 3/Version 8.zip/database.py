from sys import argv
import locale
locale.setlocale(locale.LC_ALL, "en_US")
import json
def main():              #This function returns a list which includes both the name of the table and datas as dictionaries.
    datas=[]             #Keeps datas acquired from "INSERT" section as lists in a list.
    data_list=[]         #Keeps the table's name and datas as dictionaries.    
    columns_dict={}      #Was used to add datas to "data_list"
    conditions=[]
    condition_list=[]
    updating=[]
    deleting=[]
    with open(argv[1].strip(),"r",encoding="utf-8") as file:
        lines=file.readlines()
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="CREATE_TABLE":
                data_list.append(splitted_line[1])
                columns=splitted_line[2].split(",")  
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="INSERT":
                counter=0
                for index,character in enumerate(line):
                    if character==" ":
                        counter+=1
                        if counter==2:
                            datas.append(line[(index+1):].strip().split(","))
        for i in datas:
            counter=0
            for k in i:
                columns_dict.update({columns[counter]:k})
                counter+=1
                copied_dict=columns_dict.copy()
            data_list.append(copied_dict) 
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="SELECT":
                conditions.append(splitted_line[1])
                wanted=splitted_line[2].split(",")
                for i in wanted:
                    conditions.append(i)
                counter=0
                for index,character in enumerate(line):
                    if character==" ":
                        counter+=1
                        if counter==4:
                            conditions.append(line[(index+1):].strip())
                            condition_list.append(conditions.copy())
                            conditions.clear()
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="UPDATE":
                updating.append(splitted_line[1])
                wanted_start_index=line.find("{")
                wanted_end_index=line.find("}")
                condition_start_index=line.find("{",wanted_start_index+1)
                condition_end_index=line.find("}",wanted_end_index+1)
                updating.append(line[wanted_start_index:wanted_end_index+1])
                updating.append(line[condition_start_index:condition_end_index+1])
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="DELETE":
                deleting.append(splitted_line[1])
                counter=0
                for index,character in enumerate(line):
                    if character==" ":
                        counter+=1
                        if counter==3:
                            be_deleted=line[(index+1):].strip()
                            deleting.append(json.loads(be_deleted))               
    return data_list,condition_list,updating,deleting
main()

def minus(a,b):       #Was used to determine the number of "-"
    return((max(len(str(a)),len(str(b)))+2)*"-")

def new_table():           #I created a list which includes the length of the columns by one by.
    mydict=[]
    WidthList=[]
    widths=[]
    columns=[]
    for dictionary in main()[0][1:]:
        last_item=tuple(dictionary.keys())[-1]    
    for dictionaries in main()[0][1:]:
        a=dictionaries.copy()
        mydict.append(a)
    for i in mydict:
        for column in i.keys():
            columns.append(column)
        break
    for dictionary in mydict:
        for key in dictionary.keys():
            for i in mydict:
                WidthList.append(i[key])
                width=len(minus(key,max(WidthList,key=len)))
                WidthList.clear()
            widths.append(width)
        break
    def bars():
        nonlocal columns
        nonlocal last_item
        k=0
        while k<4:
            for column in columns:
                if column!=last_item:
                    print("+"+(widths[k])*"-",end="")
                    k+=1
                else:
                    print("+"+(widths[k])*"-",end="")
                    print("+")
                    k+=1
    bars()
    k=0
    while k<4:
        for column in columns:
            if column!=last_item:
                print(f"| {columns[k]:<{widths[k]-2}} ",end="")
                k+=1
            else:
                print(f"| {columns[k]:<{widths[k]-2}} ",end="")
                print("|")
                k+=1
    bars()  
    for data_dictionary in mydict:
        k=0
        while k<4:    
            for value in data_dictionary.values():
                if value!=None:
                    if value!=data_dictionary[last_item]:
                        print(f"| {value:<{widths[k]-2}} ",end="")
                        k+=1
                    else:
                        print(f"| {value:<{widths[k]-2}} ",end="")
                        print("|")
                        k+=1    
    bars()

def INSERT():
    mylist=[]         #It contains the data dictionaries.
    for dictionary in main()[0][1:]:
        last_item=tuple(dictionary.keys())[-1]
    def TABLE():
        nonlocal mylist
        nonlocal dictionary
        nonlocal last_item
        a=dictionary.copy()
        mylist.append(a)
        for anydict in mylist:
            for key,value in anydict.items():
                WidthLists=[]         #Needed a list to determine what the largest string is.
                if key!=last_item:
                    for i in mylist:
                        WidthLists.append(i[key])
                    width=max(len(str(key)),len(max(WidthLists,key=len)))
                    print(f"| {value:{width}} ",end="")
                else:
                    for i in mylist:
                        WidthLists.append(i[key])
                    width=max(len(str(key)),len(max(WidthLists,key=len)))
                    print(f"| {value:{width}} ",end="")
                    print("|")

    for dictionary in main()[0][1:]:
        last_item=tuple(dictionary.keys())[-1]
        print(22*"#"+" "+"INSERT"+" "+25*"#")
        print(f"Inserted into '{main()[0][0]}': {tuple(dictionary.values())}") 
        print()
        print(f"Table: {main()[0][0]}")  
    
        for key,value in dictionary.items():    
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
    
        for key,value in dictionary.items():
            if key!=last_item:
                print(f"| {key:<{len(minus(key,value))-2}} ",end="")
            else:
                print(f"| {key:<{len(minus(key,value))-2}} ",end="")
                print("|")

        for key,value in dictionary.items():
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
    
        TABLE()
        
        for key,value in dictionary.items():
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
        
        print(55*"#")
        print()

def CREATE():
    print(22*"#"+" "+"CREATE"+" "+25*"#")
    print(f"Table '{main()[0][0]}' created with columns: {list(main()[0][1].keys())}")
    print(55*"#")
    print()

def SELECT():
    selected=[]
    SubList=[]
    for lists in main()[1]:
        condition_dictionary=json.loads(lists[-1])
        print(22*"#"+" "+"SELECT"+" "+25*"#")
        print(f"Condition: {condition_dictionary}")
        for i in condition_dictionary.keys():
            condition_key=i
        for dictionaries in main()[0][1:]:
            if condition_dictionary[condition_key]==dictionaries[condition_key]:
                if lists[1]=="*":
                    for column in dictionaries.keys():
                        SubList.append(dictionaries[column])
                    selected.append(tuple(SubList.copy()))
                    SubList.clear()
                else:
                    for column in lists[1:-1]:
                        SubList.append(dictionaries[column])
                    selected.append(tuple(SubList.copy()))
                    SubList.clear()         
        print(f"Select result from '{lists[0]}': {selected}")
        selected.clear()
        print(55*"#")
        print()

def UPDATE():
    DataList=main()[0][1:].copy()
    condition_dict=json.loads(main()[2][-1])
    wanted_dict=json.loads(main()[2][1])
    condition_keys=tuple(condition_dict.keys())
    wanted_keys=tuple(wanted_dict.keys())
    for dictionary in main()[0][1:]:
        k=0
        while k<len(condition_keys):
            if condition_dict[condition_keys[k]]==dictionary[condition_keys[k]]:
                k+=1
                if k==len(condition_keys)-1:
                    dictionary_index=DataList.index(dictionary)
                    DataList.remove(dictionary)
                    for wanted_key in wanted_keys:
                        dictionary.update({wanted_key:wanted_dict[wanted_key]})
                    DataList.insert(dictionary_index,dictionary.copy())
            else:
                break
    print(22*"#"+" "+"UPDATE"+" "+25*"#")
    print(f"Updated '{main()[2][0]}' with {main()[2][1]} where {main()[2][2]}")
    print(f"{(len(main()[2])-2)} rows updated.")
    print()
    print(f"Table: {main()[2][0]}")
    mydict=[]
    WidthList=[]
    widths=[]
    columns=[]
    for dictionary in DataList:
        last_item=tuple(dictionary.keys())[-1]    
    for dictionaries in DataList:
        a=dictionaries.copy()
        mydict.append(a)
    for i in mydict:
        for column in i.keys():
            columns.append(column)
        break
    for dictionary in mydict:
        for key in dictionary.keys():
            for i in mydict:
                WidthList.append(str(i[key]))
                width=len(minus(key,max(WidthList,key=len)))
                WidthList.clear()
            widths.append(width)
        break
    def bars():
        nonlocal columns
        nonlocal last_item
        k=0
        while k<4:
            for column in columns:
                if column!=last_item:
                    print("+"+(widths[k])*"-",end="")
                    k+=1
                else:
                    print("+"+(widths[k])*"-",end="")
                    print("+")
                    k+=1
    bars()
    k=0
    while k<4:
        for column in columns:
            if column!=last_item:
                print(f"| {columns[k]:<{widths[k]-2}} ",end="")
                k+=1
            else:
                print(f"| {columns[k]:<{widths[k]-2}} ",end="")
                print("|")
                k+=1
    bars()  
    for data_dictionary in mydict:
        k=0
        while k<4:    
            for value in data_dictionary.values():
                if value!=None:
                    if value!=data_dictionary[last_item]:
                        print(f"| {value:<{widths[k]-2}} ",end="")
                        k+=1
                    else:
                        print(f"| {value:<{widths[k]-2}} ",end="")
                        print("|")
                        k+=1    
    bars()
    print(55*"#")
    print()
       
def DELETE():
    DataList=main()[0][1:].copy()
    for i in main()[3][-1].keys():
        condition_key=i
        for dictionary in main()[0][1:]:
            if str(main()[3][-1][condition_key])==str(dictionary[condition_key]):
                DataList.remove(dictionary)
    print(22*"#"+" "+"DELETE"+" "+25*"#")
    print(f"Deleted from '{main()[3][0]}' where {main()[3][-1]}")
    print(f"{(len(main()[3][-1].keys()))} rows deleted.")
    print()
    print(f"Table: {main()[3][0]}")
    mydict=[]
    WidthList=[]
    widths=[]
    columns=[]
    for dictionary in DataList:
        last_item=tuple(dictionary.keys())[-1]    
    for dictionaries in DataList:
        a=dictionaries.copy()
        mydict.append(a)
    for i in mydict:
        for column in i.keys():
            columns.append(column)
        break
    for dictionary in mydict:
        for key in dictionary.keys():
            for i in mydict:
                WidthList.append(i[key])
                width=len(minus(key,max(WidthList,key=len)))
                WidthList.clear()
            widths.append(width)
        break
    def bars():
        nonlocal columns
        nonlocal last_item
        k=0
        while k<4:
            for column in columns:
                if column!=last_item:
                    print("+"+(widths[k])*"-",end="")
                    k+=1
                else:
                    print("+"+(widths[k])*"-",end="")
                    print("+")
                    k+=1
    bars()
    k=0
    while k<4:
        for column in columns:
            if column!=last_item:
                print(f"| {columns[k]:<{widths[k]-2}} ",end="")
                k+=1
            else:
                print(f"| {columns[k]:<{widths[k]-2}} ",end="")
                print("|")
                k+=1
    bars()  
    for data_dictionary in mydict:
        k=0
        while k<4:    
            for value in data_dictionary.values():
                if value!=None:
                    if value!=data_dictionary[last_item]:
                        print(f"| {value:<{widths[k]-2}} ",end="")
                        k+=1
                    else:
                        print(f"| {value:<{widths[k]-2}} ",end="")
                        print("|")
                        k+=1    
    bars()
    print(55*"#")
    print()











    









        
















































