from sys import argv
import locale
locale.setlocale(locale.LC_ALL, "en_US")
import json
def main():              #This function returns a list which includes both the name of the table and datas as dictionaries.
    datas=[]             #Keeps datas acquired from "INSERT" section as lists in a list.
    data_list=[]         #Keeps the table's name and datas as dictionaries.    
    columns_dict={}      #Was used to add datas to "data_list"
    condition_list=[]
    with open(argv[1].strip(),"r",encoding="utf-8") as file:
        lines=file.readlines()
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="CREATE_TABLE":
                data_list.append(splitted_line[1])
                columns=splitted_line[2].split(",")  
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="INSERT":
                counter=0
                for index,character in enumerate(line):
                    if character==" ":
                        counter+=1
                        if counter==2:
                            datas.append(line[(index+1):].strip().split(","))
        for i in datas:
            counter=0
            for k in i:
                columns_dict.update({columns[counter]:k})
                counter+=1
                copied_dict=columns_dict.copy()
            data_list.append(copied_dict) 
        for line in lines:
            splitted_line=line.split()
            if splitted_line[0]=="SELECT":
                condition_list.append(splitted_line[1])
                wanted=splitted_line[2].split(",")
                for i in wanted:
                    condition_list.append(i)
                counter=0
                for index,character in enumerate(line):
                    if character==" ":
                        counter+=1
                        if counter==4:
                            condition_list.append(line[(index+1):].strip())
    return data_list,condition_list
main()

def minus(a,b):       #Was used to determine the number of "-"
    return((max(len(str(a)),len(str(b)))+2)*"-")

def INSERT():
    mylist=[]         #It contains the data dictionaries.
    for dictionary in main()[0][1:]:
        last_item=tuple(dictionary.keys())[-1]
    def TABLE():
        nonlocal mylist
        nonlocal dictionary
        nonlocal last_item
        a=dictionary.copy()
        mylist.append(a)
        for anydict in mylist:
            for key,value in anydict.items():
                WidthLists=[]         #Needed a list to determine what the largest string is.
                if key!=last_item:
                    for i in mylist:
                        WidthLists.append(i[key])
                    width=max(len(str(key)),len(max(WidthLists,key=len)))
                    print(f"| {value:{width}} ",end="")
                else:
                    for i in mylist:
                        WidthLists.append(i[key])
                    width=max(len(str(key)),len(max(WidthLists,key=len)))
                    print(f"| {value:{width}} ",end="")
                    print("|")

    for dictionary in main()[0][1:]:
        last_item=tuple(dictionary.keys())[-1]
        print(22*"#"+" "+"INSERT"+" "+25*"#")
        print(f"Inserted into '{main()[1][0]}': {tuple(dictionary.values())}") 
        print()
        print(f"Table: {main()[1][0]}")  
    
        for key,value in dictionary.items():    
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
    
        for key,value in dictionary.items():
            if key!=last_item:
                print(f"| {key:<{len(minus(key,value))-2}} ",end="")
            else:
                print(f"| {key:<{len(minus(key,value))-2}} ",end="")
                print("|")

        for key,value in dictionary.items():
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
    
        TABLE()
        
        for key,value in dictionary.items():
            if key!=last_item:
                print("+"+minus(key,value),end="")
            else:
                print("+"+minus(key,value),end="")
                print("+")
        
        print(55*"#")
        print()

def CREATE():
    print(22*"#"+" "+"CREATE"+" "+25*"#")
    print(f"Table '{main()[0][0]}' created with columns: {list(main()[0][1].keys())}")
    print(55*"#")
    print()

def SELECT():
    selected=[]
    condition_dict=json.loads(main()[1][-1])
    for i in condition_dict.keys():
        condition_key=i
    if main()[0][0]==main()[1][0]:
        for dictionary in main()[0][1:]:
            if dictionary[condition_key]==condition_dict[condition_key]:
                selected.append((dictionary[main()[1][1]],dictionary[main()[1][2]]))
    print(22*"#"+" "+"SELECT"+" "+25*"#")
    print(f"Condition: {condition_dict}")
    print(f"Select result from '{main()[0][0]}': {selected}")
    print(55*"#")
    print()

CREATE()
INSERT()
SELECT()

    












        
















































